from flask import Flask, request, render_template
import google.generativeai as genai
from PIL import Image
import io

# Inisialisasi Aplikasi Flask
app = Flask(__name__)

# --- KONFIGURASI PENTING ---
# Ganti dengan API Key Gemini Anda yang asli
GOOGLE_API_KEY = 'AIzaSyAyK5c8fbZiRct2qErVL5ZM0wBelXs2asQ'

# Konfigurasi model Gemini
try:
    genai.configure(api_key=GOOGLE_API_KEY)
    model = genai.GenerativeModel('gemini-1.5-flash')
    print("Berhasil terhubung ke Gemini AI.")
except Exception as e:
    print(f"Gagal konfigurasi Gemini AI: {e}")
    model = None

# Fungsi untuk menganalisis (diambil dari script sebelumnya, sedikit diubah)
def analyze_trading_chart(image_bytes):
    if not model:
        return "Error: Model AI tidak terkonfigurasi. Cek API Key."

    try:
        img = Image.open(io.BytesIO(image_bytes))
        
        prompt = """
        Anda adalah seorang analis teknikal trading profesional.
        Analisis gambar chart trading ini secara mendalam.
        Berdasarkan analisis teknikal (pola candlestick, tren, support & resistance, dan indikator), berikan:
        
        1.  **Saran Aksi:** BUY atau SELL atau WAIT (Tunggu).
        2.  **Rekomendasi Take Profit (TP):** Level harga yang masuk akal.
        3.  **Rekomendasi Stop Loss (SL):** Level harga yang masuk akal.
        4.  **Alasan Singkat:** Jelaskan dasar analisismu dengan jelas dan singkat.
        """
        
        response = model.generate_content([prompt, img])
        return response.text

    except Exception as e:
        return f"Terjadi error saat menganalisis gambar: {e}"

# Ini adalah halaman utama aplikasi kita
@app.route('/', methods=['GET', 'POST'])
def index():
    result_text = None
    if request.method == 'POST':
        # Cek apakah ada file yang di-upload
        if 'image' not in request.files:
            return "Tidak ada file yang dipilih!", 400
        
        file = request.files['image']
        
        # Cek jika nama filenya kosong
        if file.filename == '':
            return "Tidak ada file yang dipilih!", 400
            
        if file:
            # Baca file gambar sebagai bytes
            img_bytes = file.read()
            # Panggil fungsi analisis
            result_text = analyze_trading_chart(img_bytes)

    # Tampilkan halaman web (index.html) dan kirim hasilnya jika ada
    return render_template('index.html', result=result_text)

# Bagian untuk menjalankan server Flask
if __name__ == '__main__':
    # host='0.0.0.0' agar bisa diakses dari browser di jaringan yang sama
    app.run(host='0.0.0.0', port=5000)
